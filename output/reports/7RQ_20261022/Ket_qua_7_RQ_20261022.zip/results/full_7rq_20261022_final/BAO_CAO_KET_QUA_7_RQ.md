# BÁO CÁO KẾT QUẢ CHẠY TOÀN BỘ 7 RQ

Bản tham chiếu hoàn tất lúc 20:40:18 22/10/2026 (Asia/Saigon). Đã chạy cấu hình đầy đủ, không dùng --smoke. Cả 7 RQ thực thi thành công; 129 kiểm thử đạt; validator kết quả đạt 7/7. Chạy lặp lại không phát hiện khác biệt ở 22 file JSON/CSV. Đây là bộ kết quả offline cố định để đối chiếu; dữ liệu dashboard real-time có thể thay đổi theo block.

RQ1, RQ2, RQ4 có kết quả dùng được trong phạm vi hiện tại. RQ3, RQ5, RQ6, RQ7 là kết quả thăm dò. Chạy thành công và kiểm tra kỹ thuật đạt không đồng nghĩa mọi giả thuyết đã được chứng minh hoặc dữ liệu đã đủ cho kết luận toàn thị trường.

## 1. Dữ liệu, phạm vi và cấu hình thực chạy

| Mục | Giá trị |
| --- | --- |
| Lịch sử sự kiện | 2023-01-27T00:00:00Z đến trước 2026-10-01T00:00:00Z — bao gồm hết 30/09/2026 UTC |
| Block lịch sử | 16,494,436 – 26,093,737 |
| Snapshot Aave V3 Ethereum | Block 21,762,264, trước stress 03/02/2025 UTC; revision 6 |
| Vũ trụ vị thế tại snapshot | 32,847 ví lịch sử được quét; 17,084 ví có nợ, tất cả qua validation |
| Nợ theo snapshot | 11,113,944,830.71 USD (risk debt theo adapter) |
| Nguồn cố định | C:\Users\HAI NAM\Finance1\defi-research\data\runs\recovery_20261020 |
| Chạy RQ4 | Aave V3; không gộp dữ liệu ba protocol để fit chung |
| Python / NumPy / SciPy | 3.12.14 / 2.5.4 / 1.18.1 |
| Seed / bootstrap | 42 / 300 lần |
| Giới hạn vòng cascade cuối | 200; đã đối chiếu RQ7 với 400 vòng |

Lịch sử đầy kỳ không đồng nghĩa có toàn bộ vị thế ở mọi thời điểm: các bài toán vị thế dùng một snapshot; mạng cross-protocol dùng mẫu. Các CSV được đối chiếu SHA-256 với freeze_manifest trước khi chạy. Database được mở read-only; báo cáo không crawl lại hoặc sửa dataset đã freeze.

## 2. Các lần chạy, vấn đề phát hiện và cách xử lý

| Bước | Kết quả | Xử lý / đánh giá |
| --- | --- | --- |
| Kiểm tra code | 129/129 unit tests đạt | Bao gồm crawler RPC, mô hình, live dashboard và công cụ so sánh |
| Chạy đầy đủ với cấu hình gốc | 7/7 chạy xong; RQ7 có 22/81 kịch bản chạm 20 vòng | Giữ lần chạy baseline để truy vết; chưa dùng các kịch bản bị cắt làm kết quả cuối |
| Chạy đầy đủ với max_rounds=200 | RQ7 không còn chạm giới hạn; dài nhất 35 vòng | Lưu cấu hình riêng configs/models.full_7rq_20261022.json; giữ nguyên engine và dữ liệu |
| Kiểm tra độ ổn định RQ7 | 200 so với 400 vòng: policy_grid.csv giống hệt byte | Đây là kiểm tra ổn định giới hạn vòng trong engine hiện có, không phải xác minh engine đúng Aave thực tế |
| Chạy lại cả 7 cùng cấu hình | 22 file đối chiếu; 0 khác biệt | Counts so sánh chính xác; số liên tục rtol=1e-9, atol=1e-6 |
| Validator kết quả | 7/7 đạt; không còn cảnh báo chạm vòng | Kiểm tra hữu hạn, số dư, concentration, matching, optimizer và Pareto |

Không phát hiện lỗi thực thi cần sửa trong engine ở lần chạy này. Thay đổi phục vụ lần chạy: tăng giới hạn vòng trong cấu hình riêng, thêm script đối chiếu kết quả và script tạo báo cáo. Các hạn chế về nhận diện nhân quả, giá thiếu, mẫu mạng và hiệu chỉnh cascade vẫn được giữ nguyên, không che bằng thay đổi code.

## 3. RQ1 — Giá ETH/BTC giảm bao nhiêu tạo bước nhảy trong thanh lý?

Đo nợ đủ điều kiện thanh lý theo HF, không phải lượng thanh lý đã thực thi. Quét 0–60%, bước 1%, shock cả tài sản thế chấp và nợ theo nhóm token. Ngưỡng mô tả trong một snapshot, chưa có kiểm định ngưỡng thống kê.

| Kịch bản | Khoảng giảm có bước tăng lớn nhất | Nợ đủ điều kiện tăng thêm (USD) | Nút hồi quy đoạn thẳng |
| --- | --- | --- | --- |
| ETH_only | 41.00% → 42.00% | 190,134,275.69 | 26.00% |
| BTC_only | 47.00% → 48.00% | 97,178,064.06 | 29.00% |
| ETH_BTC_joint | 41.00% → 42.00% | 181,286,005.75 | 21.00% |

| Kịch bản shock đồng thời | Ví đủ điều kiện | Ví mới đủ điều kiện so với nền | Nợ đủ điều kiện (USD) |
| --- | --- | --- | --- |
| 0.00% | 601 | 0 | 29,460.69 |
| 10.00% | 1072 | 489 | 152,377,102.62 |
| 20.00% | 1974 | 1405 | 588,401,341.55 |
| 30.00% | 3404 | 2846 | 1,180,407,056.33 |
| 60.00% | 8796 | 8266 | 3,557,133,971.85 |

Ở nền đã có 601 ví HF<1, tổng risk debt 29,460.69 USD. Cột ví mới loại nhóm này. Không nên diễn giải số ví nền như số khoản vay lớn đang có thể thanh lý sinh lời.

## 4. RQ2 — Thanh lý có tập trung ở ví/token/protocol?

| Protocol | Sự kiện thanh lý | Sự kiện có giá USD | Tỷ lệ có giá |
| --- | --- | --- | --- |
| aave_v3 | 27578 | 23580 | 85.50% |
| compound_v3_usdc | 1381 | 1381 | 100.00% |
| morpho_blue | 6323 | 3651 | 57.74% |

| Protocol / thước đo / chiều phân nhóm | HHI | Gini | Top 1 | Top 10 |
| --- | --- | --- | --- | --- |
| aave_v3 / event_count / borrower | 0.000428 | 0.443448 | 1.44% | 3.30% |
| aave_v3 / reported_amount_market_usd_priced_subset / borrower | 0.007364 | 0.945265 | 3.25% | 20.39% |
| compound_v3_usdc / event_count / borrower | 0.001613 | 0.165065 | 1.67% | 7.82% |
| compound_v3_usdc / reported_amount_market_usd_priced_subset / borrower | 0.029792 | 0.942538 | 8.38% | 46.03% |
| morpho_blue / event_count / borrower | 0.002357 | 0.425470 | 2.39% | 11.96% |
| morpho_blue / reported_amount_market_usd_priced_subset / borrower | 0.019320 | 0.949861 | 5.58% | 37.65% |

Hình thức tập trung theo lượng USD có thể khác theo số sự kiện. Các chỉ số USD chỉ phản ánh phần có giá; không nội suy phần thiếu. Comet basePaidOut không có cùng nghĩa với Aave debt repaid, vì vậy không cộng USD giữa ba protocol thành một tổng thanh lý. Xem concentration.csv cho chi tiết từng năm và từng token.

## 5. RQ3 — Đòn bẩy lặp liên hệ với độ dễ tổn thương như thế nào?

| Chỉ tiêu | Kết quả |
| --- | --- |
| Nhãn / cửa sổ nhận diện | temporal / 24 giờ; bằng chứng phải có trước cutoff |
| Cutoff / kết thúc outcome | 2025-02-02T23:59:47+00:00 / 2025-02-09T23:59:47+00:00 |
| Ví gắn nhãn / cặp match / ví không match | 3,863 / 3,656 / 207 |
| Tỷ lệ bị thanh lý 7 ngày: nhóm nhãn / đối chứng | 7.41% / 5.88% |
| Chênh lệch rủi ro | 1.5317 điểm phần trăm |
| Bootstrap 95% cho chênh lệch | 0.6968 – 2.4774 điểm phần trăm |
| Chênh lệch đủ điều kiện khi shock 20% | 2.3523 điểm phần trăm |
| Logistic penalized | penalized_association_only; converged=True |

| Biến match | Standardized mean difference sau match |
| --- | --- |
| log1p_debt | 0.008107 |
| HF_capped_10 | -0.013184 |
| ETH_collateral_share | -0.001372 |
| BTC_collateral_share | 0.000819 |

Kết quả là liên hệ có điều kiện trong các cặp được match. Nhãn temporal chỉ là ứng viên leverage lặp; nhóm không thấy motif chưa được chứng minh là không có leverage. Bootstrap giữ matching cố định. Chưa thể phát biểu leverage gây ra mức tăng rủi ro này hoặc suy rộng toàn thị trường.

## 6. RQ4 — Thanh lý có clustering/self-excitation theo thời gian?

| Chỉ tiêu | Kết quả |
| --- | --- |
| Sự kiện / giờ quan sát | 27,578 / 32,232 |
| Mốc train/test (UTC) | 2026-01-05T09:00:00+00:00 |
| Half-life Hawkes được chọn trên train | 5.0000 phút |
| Branching ratio | 0.822687 |
| Hawkes test log-likelihood | 28950.550282 |
| Hawkes trừ constant Poisson: test log-likelihood | 36859.173405 |
| Poisson có controls: test deviance | 68900.358208 |
| Constant Poisson: test deviance | 79627.690255 |
| Giảm deviance so với constant | 13.47% |
| Optimizer / số giờ loại vì giá | Poisson và Hawkes hội tụ / 1 |

Trong cấu hình đang xét, Hawkes fit holdout tốt hơn constant Poisson, phù hợp mô tả thanh lý có cụm. Branching ratio không chứng minh cơ chế nhân quả: Hawkes chưa kiểm soát giá và kiểm định residual time-rescaling; timestamp được nhóm theo block. Poisson có giá cùng giờ là mô hình giải thích, không phải dự báo trước giờ. Không so trực tiếp log-likelihood point-process với hourly deviance vì chúng khác thước đo.

## 7. RQ5 — Cross-protocol exposures có tạo kênh lây lan?

Mẫu 69 ví, 188 cạnh định giá được, 10 dòng chưa có giá; block đồng bộ 21762264. Đây là mạng mẫu theo hoạt động, chưa phải toàn thị trường.

| Cặp protocol | Ví cùng có nợ | Tổng min(nợ ở hai bên) (USD) |
| --- | --- | --- |
| aave_v3 ↔ compound_v3_usdc | 0 | 0.00 |
| aave_v3 ↔ morpho_blue | 0 | 0.00 |
| compound_v3_usdc ↔ morpho_blue | 1 | 12,555,081.43 |

Mẫu tìm thấy common-wallet exposure giữa Compound V3 và Morpho. Không thấy overlap Aave trong mẫu không chứng minh thị trường không có kênh này. Exposure chung không phải khoản phải thu trực tiếp giữa protocol; chưa ước lượng được tổn thất truyền dẫn hoặc causal contagion.

## 8. RQ6 — Mô phỏng cascade và tác động thanh khoản

| Shock ETH/BTC | Repayment có impact (USD) | Repayment zero-impact (USD) | Tỷ lệ | Impact lớn nhất | Shortfall cuối có impact (USD) | Ví còn HF<1 |
| --- | --- | --- | --- | --- | --- | --- |
| 10.00% | 148,972,512.90 | 77,642,377.14 | 1.9187x | 4.70% | 54,276.77 | 891 |
| 20.00% | 604,178,350.37 | 385,261,769.15 | 1.5682x | 9.09% | 2,675,078.10 | 1522 |
| 30.00% | 1,307,041,758.79 | 918,768,933.95 | 1.4226x | 13.25% | 45,515,072.33 | 2860 |

Giả định: độ sâu 100,000,000.00 USD cho mỗi token, impact coefficient 0.05, oracle pass-through 1.0, close factor 0.5, bonus 5.00%, gas 20.00 USD/action và phí DEX 0.30%. Shock đồng thời áp dụng cả collateral và debt theo factor.

Cả 6 kịch bản dừng vì không còn thanh lý sinh lời theo bộ lọc đồng bộ của engine; còn ví HF<1 là một đầu ra cần giữ. Shortfall là chênh lệch kế toán mô hình, không phải bad debt ghi nhận on-chain. Tỷ lệ repayment có/không impact chỉ là sensitivity của engine, chưa phải hệ số khuếch đại thực nghiệm. Chưa hiệu chỉnh liquidity depth/impact hoặc tái tạo chính xác Aave pair, close factor động, dust, protocol fee và tuyến thực thi.

## 9. RQ7 — Độ nhạy tham số và Pareto

Chạy 81 kịch bản = 3 shock × 3 close factor × 3 bonus × 3 thay đổi LT. Tất cả 81 đủ điều kiện Pareto về mặt giới hạn vòng; 6 phương án không bị trội trong cùng shock. Số vòng tối đa thực dùng 35. Có 81 kịch bản vẫn còn ví HF<1 khi dừng; hết giới hạn vòng và còn HF<1 là hai vấn đề khác nhau.

| Shock | Close factor | Bonus | LT shift (điểm %) | Shortfall cuối USD | Collateral seized USD | Impact | Ví còn HF<1 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 10.00% | 25.00% | 3.00% | +3.0 | 15,985.36 | 33,293,468.36 | 2.49% | 704 |
| 10.00% | 100.00% | 3.00% | -3.0 | 15,959.12 | 310,797,446.20 | 6.05% | 1748 |
| 20.00% | 100.00% | 3.00% | -3.0 | 17,172.65 | 187,876,023.64 | 3.84% | 2776 |
| 20.00% | 100.00% | 3.00% | +0.0 | 20,284.87 | 145,210,632.96 | 4.04% | 1989 |
| 20.00% | 100.00% | 3.00% | +3.0 | 20,328.93 | 123,396,046.61 | 4.02% | 1504 |
| 30.00% | 100.00% | 3.00% | -3.0 | 10,064,680.34 | 225,309,864.70 | 4.26% | 4157 |

Pareto tối thiểu hóa đồng thời shortfall, collateral seized và impact, so sánh riêng trong mỗi shock. Không có một bộ tham số tối ưu duy nhất. Frontier phụ thuộc hàm mục tiêu và engine giả định, giữ số dư ban đầu cố định khi đổi LT, bỏ qua phản ứng người vay. Không sử dụng bảng này như khuyến nghị tham số Aave thực tế.

## 10. Mức sẵn sàng và việc còn thiếu

| RQ | Mức dùng được | Giới hạn / bước tiếp theo |
| --- | --- | --- |
| 1 | Đạt trong phạm vi | Stress một snapshot; cần panel nhiều ngày và kiểm định ngưỡng để suy rộng |
| 2 | Đạt trong phạm vi | Đủ counts lịch sử; bổ sung giá cho phần thiếu trước khi kết luận USD toàn bộ |
| 3 | Thăm dò | Cần xác minh funding đại diện, sensitivity nhãn/cửa sổ và thiết kế nhận diện nhân quả |
| 4 | Đạt trong phạm vi | Cần residual diagnostics, mô hình covariates phù hợp và robustness nhiều giai đoạn |
| 5 | Thăm dò | Cần toàn bộ exposure đồng bộ nhiều ngày và nhận diện kênh truyền dẫn |
| 6 | Thăm dò | Cần hiệu chỉnh liquidity/impact và replay đúng revision trên nhiều wave ngoài mẫu |
| 7 | Thăm dò | Phụ thuộc RQ6 được kiểm chứng; bổ sung phản ứng người vay và robustness mục tiêu |

## 11. Lệnh tự chạy và so sánh

Chạy trong thư mục repository. Giữ nguyên data-run, cấu hình và phiên bản thư viện. Không dùng --smoke. Dùng thư mục kết quả mới chưa tồn tại; không ghi đè bản tham chiếu. Bản tham chiếu local là results/full_7rq_20261022_final.

```powershell
.\.venv\Scripts\python.exe -m defi_models check --config configs/models.full_7rq_20261022.json
.\.venv\Scripts\python.exe -m defi_models all --config configs/models.full_7rq_20261022.json --allow-exploratory --out results/my_7rq_comparison
.\.venv\Scripts\python.exe scripts/validate_model_run.py results/my_7rq_comparison
.\.venv\Scripts\python.exe scripts/compare_model_runs.py results/full_7rq_20261022_final results/my_7rq_comparison --json-out results/my_7rq_comparison/comparison.json
```

Có thể thay all bằng rq1 … rq7 để chạy riêng; RQ5–7 cần --allow-exploratory. Script compare dùng được với hai lần chạy cùng danh sách RQ. Với bộ cả 7, kết quả mong đợi: passed=true, files_compared=22, difference_count=0. Khác đường dẫn máy và thời gian chạy không tạo khác biệt; cấu hình, identities của input, counts và file kết quả đều được đối chiếu. Phiên bản thư viện được hiển thị để kiểm tra. So sánh chỉ đọc các file cần thiết; nó không tự xác minh lại toàn bộ SQLite.

```powershell
.\.venv\Scripts\python.exe -m pip install -r results/full_7rq_20261022_final/requirements-reference.txt
.\.venv\Scripts\python.exe scripts/build_7rq_results_report.py results/full_7rq_20261022_final
```

Dataset đã freeze nằm ngoài GitHub. Gói báo cáo không chứa database 11+ GB; máy khác cần bản dữ liệu riêng giữ nguyên cấu trúc, audits và freeze manifest. Để đổi chỗ dataset dùng --data-run. requirements-reference.txt ghi đúng phiên bản đã chạy; cần Python 3.12.14 để khớp môi trường tham chiếu. Lệnh tạo báo cáo đọc các file kiểm tra đã lưu; nó không tự chạy lại mô hình hoặc test.

## 12. Các file dùng để kiểm chứng

| File / thư mục trong bộ kết quả | Nội dung |
| --- | --- |
| rq1/ … rq7/ | CSV kết quả và summary.json phương pháp/giới hạn |
| manifest.json / config.json | Lệnh, phiên bản, timing, data-run, cấu hình thực chạy và input hashes |
| validation.json | Kết quả validator đầu ra |
| reproducibility.json | Đối chiếu hai lần chạy đầy đủ |
| convergence.json | Đối chiếu RQ7 max_rounds 200 và 400 |
| code_identity.json / requirements-reference.txt | SHA-256 mã nguồn và phiên bản thư viện |
| result_checksums.json | SHA-256 của các CSV và summary.json dùng để đối chiếu |
| TONG_HOP_RQ.csv | Bảng trạng thái từng RQ dạng CSV UTF-8 |
| BAO_CAO_KET_QUA_7_RQ.html / .md | Báo cáo này; HTML tự chứa, mở offline và có thể Print → Save as PDF |
