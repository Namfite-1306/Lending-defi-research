# Kết quả chạy mô hình

Chế độ: research_run.

| RQ | Chạy | Phạm vi kết quả |
|---|---|---|
| RQ1 | completed | ready_scoped |
| RQ2 | completed | ready_scoped |
| RQ3 | completed | exploratory |
| RQ4 | completed | ready_scoped |
| RQ5 | completed | exploratory |
| RQ6 | completed | exploratory |
| RQ7 | completed | exploratory |

Mỗi thư mục có summary.json ghi phương pháp và giới hạn, CSV ghi kết quả. completed không đồng nghĩa kết luận nghiên cứu đã được kiểm chứng.